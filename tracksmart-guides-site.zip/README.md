# TrackSmart AI — Quick-Start Guides (site)

This whole folder is ONE website that hosts all your engine guides under a single
subdomain: https://start.tracksmartracing.com/

    index.html            -> the hub ("Choose Your Engine")
    og-image.png          -> hub link-preview banner
    flagship/index.html   -> Prompt 59 BRIS Flagship guide
    flagship/og-image.png -> that guide's banner

Adding more engines does NOT need new subdomains or DNS changes — ever. Each engine
is just a new folder, e.g.  prompt-61/index.html , served at  /prompt-61/ .

## Deploy once
1. GitHub repo -> upload everything in this folder (keep the folder structure).
   (Drag the files in; or upload the zip's contents.)
2. Settings -> Pages -> Source: Deploy from a branch -> main / (root).
3. Settings -> Pages -> Custom domain: start.tracksmartracing.com -> Save.
4. DNS (one time): add a CNAME record  start -> dslowrycpa.github.io
   - Namecheap "BasicDNS": Advanced DNS tab -> Add Record -> CNAME, Host=start,
     Value=dslowrycpa.github.io. Leave the existing @ and www records (Wix) alone.
   - If nameservers point to Wix: add the same CNAME in Wix -> Manage DNS Records.
5. Once it resolves (dnschecker.org, CNAME, start.tracksmartracing.com -> github.io),
   tick "Enforce HTTPS" in Settings -> Pages.

Live URLs:
   Hub:      https://start.tracksmartracing.com/
   Flagship: https://start.tracksmartracing.com/flagship/

## Adding each new engine
Send me the engine's instructions (like the Prompt 59 doc) plus:
  - display name, sport (thoroughbred/harness/greyhound), data provider, folder name.
I'll build /<folder>/index.html + /<folder>/og-image.png and add a card to the hub.
You just upload the new folder and the updated index.html. No DNS, no settings.
